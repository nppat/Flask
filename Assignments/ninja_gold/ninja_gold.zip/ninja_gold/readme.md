Ninja Gold

Front-end
- 1) Create 4 forms (farm,cave,house,casino) [x]
- 2) Forms each have a hidden value [x]
- 3) Create area to print off the results of processing the gold [x]
- 4) Show user gold at top of page [x]

Back-end
- 1) create 2 routes ('/','/process_money') [x]
- 2) Create logic in /process_money to process the gold [x]
- 3) Send out gold count to displays on index.html [x]
- 4) Set up reset button [x]