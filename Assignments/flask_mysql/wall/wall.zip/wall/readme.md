The Wall
-  1) Create Index.html with login and register features [x]
-  2) Create wall.html [x]
--  Nav bar with Welcome {{ user['first_name']}} and log off button [x]
--  Message input and submit button [x]
--  Posts from user [x]
--  Ability to post comments to others [x]
--  Extra Credit 1 - Allow users to delete own message  [ ]
--  Extra Credit 2 - Allow user to delete message only if posted in the last 30 min [ ]