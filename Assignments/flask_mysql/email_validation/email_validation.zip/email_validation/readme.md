Email Validation w/ DB

- 1) Create index.html with form input for an email address [x]
- 2) Validate email address input [x]
- 3) Validate email format [x]
- 4) Save valid email address to database [x]
- 5) On success, display email address entered along w/ date and time it was entered [ish]
- 6) BONUS -> Add feature to delete email record on the success page []